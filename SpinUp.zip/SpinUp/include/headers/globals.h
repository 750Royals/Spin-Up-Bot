#include "main.h"

extern pros::Controller controller;

extern pros::Motor backRight;
extern pros::Motor frontRight;
extern pros::Motor backLeft;
extern pros::Motor frontLeft;

